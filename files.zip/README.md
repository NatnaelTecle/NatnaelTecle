# Nate Tecle Portfolio
Upload these files to a GitHub repo named `<username>.github.io` (or any repo with Pages enabled: Settings > Pages > Deploy from branch > main / root).
Search for "todo" in each file to find placeholders.
